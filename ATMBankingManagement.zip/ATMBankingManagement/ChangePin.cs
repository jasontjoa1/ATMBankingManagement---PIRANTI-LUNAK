﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMBankingManagement
{
    public partial class ChangePin : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\Documents\ATMDb.mdf;Integrated Security=True;Connect Timeout=30");
        public string AccNumber = Login.AccNumber;
        public ChangePin()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

            if (Newtb.Text == "" || Confirmtb.Text == "")
            {
                MessageBox.Show("Enter and Confirm The New PIN");
            } else if (Newtb.Text != Confirmtb.Text)
            {
                MessageBox.Show("PIN don't match");
            }
            else
            {
                
                try
                {
                    Con.Open();
                    string query = "update AccountTbl set PIN=" + Newtb.Text + " where Accnum='" + AccNumber + "'";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully changed");
                    Con.Close();
                    Home home = new Home();
                    home.Show();
                    this.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                Con.Close();


            }
        }

        private void ChangePin_Load(object sender, EventArgs e)
        {

        }
    }
}
